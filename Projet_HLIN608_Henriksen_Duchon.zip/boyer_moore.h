#ifndef __BOYERMOORE_H__
#define __BOYERMOORE_H__

int* searchBM(std::string pathRead, std::string search);

#endif