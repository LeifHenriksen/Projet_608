#ifndef __NAIVE_H__
#define __NAIVE_H__

int* searchN(std::string pathRead, std::string search);

#endif